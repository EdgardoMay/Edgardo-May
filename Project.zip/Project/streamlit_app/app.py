import streamlit as st
import pymongo
import pandas as pd
import plotly.express as px
from datetime import datetime

# Configuración general
st.set_page_config(page_title="ETL Dashboard", layout="wide")

# Estilo según modo
base_theme = st.get_option("theme.base")
bg_color = "#0e1117" if base_theme == "dark" else "#ffffff"
font_color = "#fafafa" if base_theme == "dark" else "#000000"

# Conexión a MongoDB
mongo_uri = "mongodb://mongo:27017/"
client = pymongo.MongoClient(mongo_uri)

# Función para cargar datos desde MongoDB
def load_data(db_name, collection_name):
    db = client[db_name]
    collection = db[collection_name]
    data = list(collection.find({}, {"_id": 0}))
    return pd.DataFrame(data)

# Tabs
tabs = st.tabs(["🌦️ Air Quality", "📰 News", "📄 Federal Register"])

# 1. Weather Tab
with tabs[0]:
    st.header("🌦️ Air Quality Data Overview")
    try:
        df_air = load_data("environment_data", "processed_air_quality")

        if df_air.empty:
            st.warning("No hay datos de calidad del aire disponibles.")
        else:
            cities = df_air["city"].unique()
            selected_city = st.selectbox("Selecciona una ciudad", cities)
            city_data = df_air[df_air["city"] == selected_city]

            st.success(f"Registros cargados: {len(city_data)} para {selected_city}")

            col1, col2, col3 = st.columns(3)
            col1.metric("🌡️ Temp Promedio (2m)", f"{city_data['temperature_2m'].mean():.1f} °C")
            col2.metric("🌡️ Temp Promedio (80m)", f"{city_data['temperature_80m'].mean():.1f} °C")
            col3.metric("☔ Lluvia Promedio", f"{city_data['precipitation_probability'].mean():.1f} %")

            fig_temp = px.line(city_data, x="timestamp", y=["temperature_2m", "temperature_80m"], title="Temperaturas por hora")
            st.plotly_chart(fig_temp, use_container_width=True)

            fig_rain = px.line(city_data, x="timestamp", y="precipitation_probability", title="Probabilidad de precipitación")
            st.plotly_chart(fig_rain, use_container_width=True)
    except Exception as e:
        st.warning(f"No se pudieron cargar datos de clima: {e}")

# 2. NewsAPI Tab
with tabs[1]:
    st.header("📰 News Data Overview")
    try:
        df_news = load_data("news_data", "processed_newsapi")

        if df_news.empty:
            st.warning("No hay noticias procesadas disponibles.")
        else:
            st.success(f"Noticias procesadas: {len(df_news)}")

            # Normalización y asegurarse de columnas esperadas
            expected_columns = ["source", "country", "title", "published_at", "description", "url"]
            for col in expected_columns:
                if col not in df_news.columns:
                    df_news[col] = "No disponible"

            # Gráfica por fuente (source)
            if "source" in df_news.columns:
                source_counts = df_news["source"].value_counts()
                fig_source = px.bar(x=source_counts.index, y=source_counts.values,
                                    labels={"x": "Fuente", "y": "Cantidad"},
                                    title="Noticias por fuente")
                st.plotly_chart(fig_source, use_container_width=True)

            # Noticias destacadas
            st.subheader("📰 Noticias destacadas")
            for _, row in df_news.sort_values("published_at", ascending=False).head(5).iterrows():
                st.markdown(f"### {row.get('title', 'Sin título')}")
                st.caption(f"🗞️ {row.get('source', 'Fuente desconocida')} | 📅 {row.get('published_at', '')}")
                st.write(row.get("description", "Sin descripción disponible"))
                url = row.get("url", "")
                if url and url != "No disponible":
                    st.markdown(f"[📖 Leer noticia completa]({url})", unsafe_allow_html=True)
                    st.code(url, language="text")
                st.markdown("---")

    except Exception as e:
        st.warning(f"No se pudieron cargar noticias: {e}")


# 3. Federal Register Tab
with tabs[2]:
    st.header("📄 Federal Register Overview")
    try:
        df_legal = load_data("legal_documents", "processed_federal_register")

        if df_legal.empty:
            st.warning("No hay documentos legales disponibles.")
        else:
            st.success(f"Documentos legales procesados: {len(df_legal)}")

            # Gráfica por tipo de documento
            if "document_type" in df_legal.columns:
                type_counts = df_legal["document_type"].value_counts()
                fig_type = px.pie(values=type_counts.values, names=type_counts.index, title="Distribución por tipo de documento")
                st.plotly_chart(fig_type, use_container_width=True)

            # Gráfica por agencias
            if "agency_names" in df_legal.columns:
                exploded = df_legal.explode("agency_names")
                agency_counts = exploded["agency_names"].value_counts().head(10)
                fig_agencies = px.bar(agency_counts, title="Top agencias que publican documentos", labels={"index": "Agencia", "value": "Cantidad"})
                st.plotly_chart(fig_agencies, use_container_width=True)

            # Frecuencia por fecha
            if "publication_date" in df_legal.columns:
                df_legal["publication_date"] = pd.to_datetime(df_legal["publication_date"])
                daily_counts = df_legal.groupby(df_legal["publication_date"].dt.date).size()
                fig_dates = px.bar(x=daily_counts.index, y=daily_counts.values,
                                   labels={"x": "Fecha", "y": "Cantidad"},
                                   title="Cantidad de documentos por fecha de publicación")
                st.plotly_chart(fig_dates, use_container_width=True)

            # Tabla y descripción
            st.subheader("📑 Documentos recientes")
            st.dataframe(df_legal[["title", "document_type", "publication_date", "agency_names", "description"]].sort_values("publication_date", ascending=False).head(10))

            st.markdown("""
            Estos documentos provienen del sitio oficial del [Federal Register](https://www.federalregister.gov/), que publica avisos legales, normativas, reuniones y decisiones de agencias gubernamentales de EE.UU.
            Los tipos de documentos incluyen reglas propuestas, decisiones finales, avisos de audiencia y más, emitidos por entidades como el Departamento de Salud, Justicia, Educación, entre otros.
            """)
    except Exception as e:
        st.warning(f"No se pudieron cargar documentos legales: {e}")

# Footer
st.markdown("---")
st.caption("📊 Proyecto ETL - Ingeniería en Datos | Edgardo Martín May González | Dashboard generado con Streamlit y MongoDB")
