from datetime import datetime

def transform_newsapi_data(**kwargs):
    ti = kwargs['ti']
    raw_data = ti.xcom_pull(task_ids="extract_and_load_raw_newsapi_data", key="return_value")

    print("✅ Vista previa de datos de noticias:")
    print(raw_data[:2])

    processed = []
    for article in raw_data:
        title = article.get("title", "Sin título")
        url = article.get("url")
        source = article.get("source", "unknown")
        published_at = (
            article.get("publishedAt")
            or article.get("created_utc")
            or datetime.now().isoformat()
        )

        entry = {
            "title": title,
            "source": source if source else "unknown",
            "published_at": published_at,
            "author": article.get("author", "Desconocido"),
            "description": article.get("description", ""),
            "url": url,
            "category": article.get("category", "general"),
            "country": article.get("country", "US"),
            "is_breaking_news": "breaking" in (title or "").lower(),
            "has_media": article.get("urlToImage") is not None,
            "transformation_timestamp": datetime.now().isoformat()
        }
        processed.append(entry)

    ti.xcom_push(key="processed_newsapi_data_for_load", value=processed)
    return processed
