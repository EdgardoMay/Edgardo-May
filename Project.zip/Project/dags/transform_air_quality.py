from datetime import datetime
from pymongo import MongoClient

def transform_air_quality_data(**kwargs):
    ti = kwargs['ti']
    client = MongoClient("mongo", 27017)
    db = client["etl_project"]
    raw_collection = db["raw_air_quality"]

    raw_docs = list(raw_collection.find())

    processed_all = []

    for doc in raw_docs:
        city = doc.get("city", "Desconocido")
        hourly_data = doc.get("hourly", {})

        times = hourly_data.get("time", [])
        temps_2m = hourly_data.get("temperature_2m", [])
        temps_80m = hourly_data.get("temperature_80m", [])
        precipitation_probs = hourly_data.get("precipitation_probability", [])

        for i in range(len(times)):
            record = {
                "timestamp": times[i],
                "temperature_2m": temps_2m[i] if i < len(temps_2m) else None,
                "temperature_80m": temps_80m[i] if i < len(temps_80m) else None,
                "precipitation_probability": precipitation_probs[i] if i < len(precipitation_probs) else None,
                "city": city,
                "transformation_timestamp": datetime.now().isoformat()
            }
            processed_all.append(record)

    client.close()
    ti.xcom_push(key="processed_air_quality_data_for_load", value=processed_all)
    return processed_all
