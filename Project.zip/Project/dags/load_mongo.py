from airflow.models.dag import DAG
from datetime import datetime
import pymongo
import json

# Cambiar esto a True si deseas usar Atlas
USE_ATLAS = False

# Conexiones
LOCAL_MONGO_URI = "mongodb://mongo:27017/"
ATLAS_MONGO_URI = "mongodb+srv://edgardomay:1234@bigdataupy5b.5wv3gj3.mongodb.net/?retryWrites=true&w=majority&appName=BigDataUPY5B"
MONGO_CONNECTION_STRING = ATLAS_MONGO_URI if USE_ATLAS else LOCAL_MONGO_URI


def load_processed_data_to_mongo(**kwargs):
    ti = kwargs['ti']

    collection_name = kwargs.get('collection_name')
    xcom_key = kwargs.get('xcom_key')
    xcom_task_id = kwargs.get('xcom_task_id')

    if not collection_name or not xcom_key or not xcom_task_id:
        raise ValueError("load_processed_data_to_mongo requiere 'collection_name', 'xcom_key' y 'xcom_task_id' en op_kwargs.")

    processed_data = ti.xcom_pull(task_ids=xcom_task_id, key="return_value")

    print(f"DEBUG: Contenido de processed_data recibido para carga en '{collection_name}': {processed_data[:500] if isinstance(processed_data, list) else processed_data}")
    print(f"DEBUG: Tipo de processed_data: {type(processed_data)}")

    if not processed_data:
        print(f"⚠️ ADVERTENCIA: No hay datos procesados para cargar en '{collection_name}'. Saltando carga.")
        return

    print(f"🚀 Iniciando carga de datos procesados en MongoDB ({'Atlas' if USE_ATLAS else 'local'}) en la colección: {collection_name}...")

    client = None
    try:
        client = pymongo.MongoClient(MONGO_CONNECTION_STRING)

        # Selección dinámica de base de datos
        if "air_quality" in collection_name:
            db_name = "environment_data"
        elif "federal_register" in collection_name:
            db_name = "legal_documents"
        elif "newsapi" in collection_name:
            db_name = "news_data"
        else:
            raise ValueError(f"Base de datos no definida para la colección: {collection_name}")

        db = client[db_name]
        collection = db[collection_name]

        print(f"🧹 Limpiando la colección {collection_name} antes de insertar nuevos datos...")
        collection.delete_many({})
        print("✅ Colección limpiada exitosamente.")

        # Validación de estructura
        if not isinstance(processed_data, list):
            raise ValueError("El resultado de la transformación no es una lista.")
        if not all(isinstance(doc, dict) for doc in processed_data):
            raise ValueError("Algunos elementos de la lista no son diccionarios válidos.")

        # Inserción
        insert_result = collection.insert_many(processed_data)
        print(f"✅ Datos cargados exitosamente en {db_name}.{collection_name}.")
        print(f"📦 Registros insertados: {len(insert_result.inserted_ids)}")

    except pymongo.errors.ConnectionFailure as e:
        print(f"❌ Error de conexión a MongoDB: {e}")
        raise
    except Exception as e:
        print(f"❌ Error inesperado durante la carga: {e}")
        raise
    finally:
        if client:
            client.close()
