import requests
from pymongo import MongoClient

CITIES = {
    "Mérida, Yucatán": {"latitude": 20.9674, "longitude": -89.5926},
    "Ciudad de México": {"latitude": 19.4326, "longitude": -99.1332},
    "Monterrey": {"latitude": 25.6866, "longitude": -100.3161}
}

def extract_and_load_raw_air_quality_data(**context):
    client = None
    try:
        client = MongoClient("mongo", 27017)
        db = client["etl_project"]
        collection = db["raw_air_quality"]

        for city, coords in CITIES.items():
            url = (
                f"https://api.open-meteo.com/v1/forecast?"
                f"latitude={coords['latitude']}&longitude={coords['longitude']}&"
                "hourly=temperature_2m,precipitation_probability,temperature_80m&"
                "timezone=auto&forecast_days=1"
            )

            response = requests.get(url, timeout=10)
            response.raise_for_status()
            data = response.json()
            data["city"] = city

            if "hourly" not in data:
                print(f"[WARNING] La respuesta para {city} no contiene datos 'hourly'.")
            else:
                print(f"[INFO] Registros recibidos para {city}: {len(data['hourly'].get('time', []))}")

            collection.insert_one(data)
            print(f"[INFO] Weather data for {city} successfully loaded to MongoDB (raw_air_quality).")

        return "Extraction completed for all cities."

    except requests.exceptions.RequestException as req_err:
        print(f"[ERROR] API request failed: {req_err}")
        raise
    except Exception as e:
        print(f"[ERROR] General failure during ingestion: {e}")
        raise
    finally:
        if client:
            client.close()
